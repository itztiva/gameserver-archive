#pragma once

//(TODO)

// bool ValidShot(UObject* Pawn)
// bool ValidVehicleMove(UObject* Vehicle, whatevermovementclass Move) // We can check the velocity for the vehicle and we can figure out the max velocity for each vehicle and if it goes over then make the user exit the vehicle.